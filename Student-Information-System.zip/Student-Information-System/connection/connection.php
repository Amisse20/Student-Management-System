<?php 
	$con=mysqli_connect("localhost","root","","sis_db");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>