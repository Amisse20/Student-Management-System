<footer>
      <p class="footer-bottom-text">CopyRights © 2022 Powered by Ternoin Web Trainees</p>
</footer>